import React from 'react';
import { FlatList, Text, StyleSheet, View, Image } from 'react-native';

const groudon = require('./assets/groudon.png');
const kyogre = require('./assets/kyogre.webp'); 
const xerneas = require('./assets/xerneas.webp');

const DATA = [
  { imagem: require('./assets/xerneas.webp'), titulo: 'Xerneas', 
  descricao: "Xerneas é um Pokémon Lendário do tipo Fada, introduzido na Geração 6 (região de Kalos), conhecido como o Pokémon da Vida."},
  
  { imagem: require('./assets/groudon.png'), titulo: 'Groudon', 
  descricao: "Groudon é um Pokémon Lendário do tipo Terra, introduzido na 3ª Geração (Hoenn), conhecido como o criador dos continentes e personificação da terra." },

  { imagem: require('./assets/kyogre.webp'), titulo: 'Kyogre', 
  descricao: "Kyogre é um Pokémon Lendário do tipo Água, introduzido na 3ª geração (Hoenn), conhecido como a personificação dos mares." },

];

export default function ExFlatList() {
  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text style={styles.titulo}>{item.titulo}</Text>
      <Image style={styles.img} source={item.imagem} />
      <Text>{item.descricao}</Text>
    </View>
  );

  return (
    <FlatList
      data={DATA}
      renderItem={renderItem}
    />
  );
}

const styles = StyleSheet.create({
  img: {
    container: 1,
    resizeMode: 1,
  
  },  
  titulo: {
    paddingVertical: 10,
  },
  item: {
    padding: 15,
    borderBottomWidth: 10,
    borderBottomColor: '#aaa',
  },
});