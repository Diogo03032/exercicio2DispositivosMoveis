import React from 'react';
import { FlatList, Text, StyleSheet, SafeAreaView, Image, ImageBackground, Button } from 'react-native';

const groudon = require('./assets/groudon.png');
const kyogre = require('./assets/kyogre.webp'); 
const xerneas = require('./assets/xerneas.webp');

const DATA = [
  { tipo: 'fada', fundo: require('./assets/rosa.webp'), imagem: require('./assets/xerneas.webp'), titulo: 'Xerneas', 
  descricao: "  Xerneas é um Pokémon Lendário do tipo Fada, introduzido na Geração 6 (região de Kalos), conhecido como o Pokémon da Vida."},
  
  { tipo: 'terrestre', fundo: require('./assets/vermelho.jpg'), imagem: require('./assets/groudon.png'), titulo: 'Groudon', 
  descricao: "  Groudon é um Pokémon Lendário do tipo Terra, introduzido na 3ª Geração (Hoenn), conhecido como o criador dos continentes e personificação da terra." },

  { tipo: 'agua', fundo: require('./assets/azul.webp'), imagem: require('./assets/kyogre.webp'), titulo: 'Kyogre', 
  descricao: "  Kyogre é um Pokémon Lendário do tipo Água, introduzido na 3ª geração (Hoenn), conhecido como a personificação dos mares." },

];

export default function ExFlatList() {
  const handlePress = () =>{
    alert(item.tipo)
  };
  const renderItem = ({ item }) => (
    
      <SafeAreaView style={styles.item}>
        <ImageBackground style={styles.fundo} source={item.fundo}>
          <Text style={styles.titulo}>{item.titulo}</Text>
          <Image style={styles.imagem} source={item.imagem} />
          <Text style={styles.disc}>{item.descricao}</Text>
          <Button 
            title= 'Tipo do pokemon'
            onPress={handlePress}
          />
        </ImageBackground>
      </SafeAreaView>
    
  );

  return (
    <FlatList
      data={DATA}
      renderItem={renderItem}
    />
  );
}

const styles = StyleSheet.create({
  botao: {
    paddin: 10,
  }
  imagem: {
    width: 200,
    height: 200,
    justifyContent: 'center',
  },
  fundo: {
    padding: 20,
    alignItems: 'center',
  },
  titulo: {
    paddingVertical: 10,
  },
  disc: {
    alignItems: 'center',
  },
  item: {
    marginTop: 50,
    padding: 15,
    flex: 1,
    borderWidth: 10,
    borderColor: '#aaa',
    alignItems: 'center',
    justifyContent: 'center',
  },
});